require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use('/api/', rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'Bondhu AI' }));

app.post('/api/chat', async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return res.status(503).json({ error: 'AI চালু করতে সার্ভারে GEMINI_API_KEY যোগ করতে হবে। README ফাইল দেখুন।' });
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 12) {
      return res.status(400).json({ error: 'সর্বোচ্চ ১২টি সাম্প্রতিক মেসেজ পাঠানো যাবে।' });
    }
    const contents = messages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: String(m.content || '').slice(0, 4000) }]
    })).filter(m => m.parts[0].text.trim());
    if (!contents.length || contents[contents.length - 1].role !== 'user') {
      return res.status(400).json({ error: 'একটি প্রশ্ন লিখুন।' });
    }
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: 'তুমি Bondhu AI—বাংলাভাষী ব্যবহারকারীদের সহায়ক, ভদ্র ও সহজ ভাষার AI সহকারী। সম্ভব হলে বাংলায় উত্তর দাও। ধাপে ধাপে বুঝিয়ে বলো। বিপজ্জনক বা বেআইনি কাজে সহায়তা করো না।' }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 1200 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error('Gemini API error:', data?.error?.message || response.status);
      return res.status(502).json({ error: 'AI থেকে উত্তর আনা যায়নি। API key ও সেটিংস পরীক্ষা করুন।' });
    }
    const answer = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();
    if (!answer) return res.status(502).json({ error: 'এবার উত্তর পাওয়া যায়নি। অন্যভাবে প্রশ্ন করুন।' });
    res.json({ answer });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'সার্ভারে সমস্যা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Bondhu AI running on port ${PORT}`));
